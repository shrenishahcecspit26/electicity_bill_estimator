Electricity Consumption Bill Estimator

Open index.html in a browser. Keep index.html, style.css, and script.js in the same folder.
Default test: 250 units, Domestic -> base ₹1,750, surcharge ₹0, fixed ₹50, total ₹1,800.
Git repository is included in this ZIP. GitHub URL was not available because the project was not pushed online.
